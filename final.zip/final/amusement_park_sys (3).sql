-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2025 at 11:41 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `amusement_park_sys`
--

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `game_id` int(11) NOT NULL,
  `game_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(8,2) NOT NULL,
  `min_age` int(11) DEFAULT 0,
  `max_capacity` int(11) DEFAULT NULL,
  `original_price` int(11) NOT NULL DEFAULT 200
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `games`
--

INSERT INTO `games` (`game_id`, `game_name`, `description`, `price`, `min_age`, `max_capacity`, `original_price`) VALUES
(1, 'game1', 'game1 descccccccccccc', 162.00, 10, 20, 200),
(2, 'game2', 'game22222222222222222', 5.50, 5, 22, 200),
(3, 'game3', 'game3 descccccccccccc', 32.00, 30, 30, 200),
(4, 'game4', 'game43', 14.00, 4, 42, 200),
(5, 'game5', 'game252222222', 37.75, 5, 52, 200),
(6, 'game7', 'game43', 14.00, 4, 42, 200),
(7, 'game8', 'game252222222', 151.00, 5, 52, 200),
(8, 'gam9', 'game43', 14.00, 4, 42, 200),
(9, 'game22', 'game252222222', 151.00, 5, 52, 200),
(10, 'gam333', 'desascascac', 211.00, 5, 22, 200),
(11, 'gam55555', 'desascascac3213', 2131.00, 25, 212, 200),
(12, 'gam0-32', 'desa678scascac', 51.00, 84, 4, 200),
(13, 'gam256570033', 'desascascac3213', 2131.00, 25, 212, 200),
(14, 'gam0--0989802', 'desa678scascac', 51.00, 84, 4, 200),
(15, 'gam523555', 'desascascac3213', 2131.00, 25, 212, 200),
(16, 'gam0-342222', 'desa678scascac', 51.00, 84, 4, 200),
(17, 'honda1', 'honda122', 100000.00, 90, 902, 200),
(18, 'hondasedk', 'ana dsd', 50.00, 32, 4, 200);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` float NOT NULL,
  `card_number` varchar(20) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `cvv` varchar(4) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `user_id`, `amount`, `card_number`, `expiry_date`, `cvv`, `created_at`) VALUES
(1, 16, 0, '66666', '2025-12-03', '777', '2025-05-01 07:43:25'),
(2, 16, 0, '4444', '2026-12-02', '3333', '2025-05-01 07:45:41'),
(3, 16, 0, '9999', '2026-12-12', '99', '2025-05-01 07:48:04'),
(4, 16, 24, '69', '2025-12-12', '69', '2025-05-01 07:53:09'),
(5, 16, 171, '666', '2029-11-22', '90', '2025-05-01 08:18:47'),
(6, 16, 14, 'ddsa', '2222-12-11', '55', '2025-05-01 09:24:10');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `ticket_date` date NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `total_price` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`ticket_id`, `user_id`, `game_id`, `ticket_date`, `quantity`, `total_price`, `created_at`) VALUES
(1, 1, 16, '2025-05-14', 1, 20.00, '2025-05-01 00:53:00'),
(2, 1, 9, '2025-05-21', 1, 223.00, '2025-05-01 01:34:42'),
(3, 1, 6, '2025-05-04', 1, 99.00, '2025-05-01 01:40:19'),
(4, 16, 8, '2025-05-01', 1, 24.00, '2025-05-01 07:12:19'),
(5, 16, 9, '2025-05-01', 1, 0.00, '2025-05-01 07:43:27'),
(6, 16, 7, '2025-05-01', 1, 0.00, '2025-05-01 07:45:42'),
(7, 16, 7, '2025-05-01', 1, 0.00, '2025-05-01 07:48:05'),
(8, 16, 6, '2025-05-01', 1, 24.00, '2025-05-01 07:50:57'),
(9, 16, 6, '2025-05-01', 1, 24.00, '2025-05-01 07:53:11'),
(10, 16, 7, '2025-05-01', 1, 171.00, '2025-05-01 08:18:48'),
(11, 16, 4, '2025-05-01', 1, 24.00, '2025-05-01 09:20:02'),
(12, 16, 4, '2025-05-01', 1, 24.00, '2025-05-01 09:23:21'),
(13, 16, 4, '2025-05-01', 1, 14.00, '2025-05-01 09:24:12'),
(14, 16, 6, '2025-05-01', 1, 24.00, '2025-05-01 09:29:17'),
(15, 16, 8, '2025-05-01', 1, 24.00, '2025-05-01 09:31:48');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `Role` varchar(20) NOT NULL DEFAULT 'Customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `email`, `password`, `phone`, `age`, `Role`) VALUES
(1, 'yuosef', 'yuosefjamal@gmail.com', 'yuosef123', '010328407742', 24, 'Customer'),
(4, 'jogo', 'yuosefjamal2@gmail.com', 'dsaddasds', '232222222223', 33, 'Customer'),
(15, 'ddasd', 'yuosefjadmal2@gmail.com', '24423213', '232131313133', 33, 'Customer'),
(16, 'yuosefjooo', 'jo123@gmail.com', 'jo12345', '012472940332', 28, 'Admin'),
(17, 'honda', 'honda22@gmail.com', 'honda12345', '21312312321', 33, 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`game_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `game_id` (`game_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `games`
--
ALTER TABLE `games`
  MODIFY `game_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tickets_ibfk_2` FOREIGN KEY (`game_id`) REFERENCES `games` (`game_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
